export interface Student {
  name: string;
  category: string;
  course: string;
  year: string;
}
