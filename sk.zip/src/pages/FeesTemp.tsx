import React, { useState, useEffect } from 'react';
import { PlusCircle, Search, Filter, Download } from 'lucide-react';
import supabase from '../lib/supabase';


const FeesTemp: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <h1>Under deveelopment</h1>
      </div>
    </div>
  );
};

export default FeesTemp;